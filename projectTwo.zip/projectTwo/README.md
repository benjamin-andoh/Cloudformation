Load balancer URL:  
Udagr-LoadB-BV69BVET7Y07-656169221.us-east-1.elb.amazonaws.com